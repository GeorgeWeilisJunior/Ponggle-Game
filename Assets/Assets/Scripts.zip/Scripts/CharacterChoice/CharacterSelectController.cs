using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;
using UnityEngine.SceneManagement;

public class CharacterSelectController : MonoBehaviour
{
    [Header("Data (urutannya harus sama dengan urutan GO di bawah)")]
    [SerializeField] List<CharacterData> characters = new List<CharacterData>();

    [Header("Portrait Besar (GO per karakter)")]
    [SerializeField] List<RectTransform> bigPortraits = new List<RectTransform>();

    [Header("Name Box (GO per karakter)")]
    [SerializeField] List<GameObject> nameBoxes = new List<GameObject>();

    [Header("Detail Box (GO per karakter)")]
    [SerializeField] List<GameObject> detailBoxes = new List<GameObject>();

    [Header("UI Misc")]
    [SerializeField] TMP_Text titleGlow;
    [SerializeField] Button btnLeft;
    [SerializeField] Button btnRight;
    [SerializeField] Button btnConfirm;

    [Header("Animation")]
    [SerializeField, Min(0.05f)] float slideDuration = 0.22f;
    [SerializeField] float slideOffset = 1200f;
    [SerializeField] Ease slideEase = Ease.OutCubic;
    [SerializeField] float glowScaleMin = 0.96f;
    [SerializeField] float glowScaleMax = 1.04f;
    [SerializeField] float glowPeriod = 1.8f;

    [Header("SFX Keys (opsional)")]
    [SerializeField] string sfxMoveKey = "UICarousel";
    [SerializeField] string sfxConfirmKey = "UIClick";

    [Header("Next Scene")]
    [SerializeField] string gameplaySceneName = "Stage 1";   // ganti sesuai nama scene level-pertama kamu

    int idx = 0;
    bool animating = false;

    void Awake()
    {
        if (btnLeft) btnLeft.onClick.AddListener(() => Move(-1));
        if (btnRight) btnRight.onClick.AddListener(() => Move(+1));
        if (btnConfirm) btnConfirm.onClick.AddListener(OnConfirm);
    }

    void OnEnable()
    {
        // Reset tampilan ke index 0
        for (int i = 0; i < bigPortraits.Count; i++)
        {
            if (bigPortraits[i])
            {
                bigPortraits[i].gameObject.SetActive(i == 0);
                bigPortraits[i].anchoredPosition = Vector2.zero;
                bigPortraits[i].localScale = Vector3.one;
                DOTween.Kill(bigPortraits[i]);
            }
            if (i < nameBoxes.Count && nameBoxes[i]) nameBoxes[i].SetActive(i == 0);
            if (i < detailBoxes.Count && detailBoxes[i]) detailBoxes[i].SetActive(i == 0);
        }
        idx = 0;

        // Glow pada judul
        if (titleGlow)
        {
            titleGlow.transform.DOKill();
            titleGlow.transform.localScale = Vector3.one * ((glowScaleMin + glowScaleMax) * 0.5f);
            titleGlow.transform.DOScale(glowScaleMax, glowPeriod * 0.5f)
                .SetEase(Ease.InOutSine).SetLoops(-1, LoopType.Yoyo);
        }
    }

    void Update()
    {
        if (animating) return;
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) Move(-1);
        else if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) Move(+1);
    }

    void Move(int dir)
    {
        if (animating || bigPortraits.Count == 0) return;
        int next = Mathf.Clamp(idx + dir, 0, bigPortraits.Count - 1);
        if (next == idx) return;

        if (!string.IsNullOrEmpty(sfxMoveKey)) AudioManager.I?.PlayUI(sfxMoveKey);
        StartCoroutine(SlideRoutine(idx, next, dir));
        idx = next;
    }

    IEnumerator SlideRoutine(int cur, int nxt, int dir)
    {
        animating = true;
        var curRT = bigPortraits[cur];
        var nxtRT = bigPortraits[nxt];

        if (nxtRT)
        {
            nxtRT.gameObject.SetActive(true);
            nxtRT.anchoredPosition = new Vector2((dir > 0 ? +1 : -1) * slideOffset, 0f);
            nxtRT.localScale = Vector3.one * 0.92f;
            nxtRT.DOKill();
        }
        if (curRT) curRT.DOKill();

        for (int i = 0; i < nameBoxes.Count; i++) if (nameBoxes[i]) nameBoxes[i].SetActive(i == nxt);
        for (int i = 0; i < detailBoxes.Count; i++) if (detailBoxes[i]) detailBoxes[i].SetActive(i == nxt);

        if (curRT)
        {
            curRT.DOAnchorPos(new Vector2((dir > 0 ? -1 : +1) * slideOffset, 0f), slideDuration).SetEase(slideEase);
            curRT.DOScale(0.92f, slideDuration * 0.9f).SetEase(Ease.OutSine);
        }
        if (nxtRT)
        {
            nxtRT.DOAnchorPos(Vector2.zero, slideDuration).SetEase(slideEase);
            nxtRT.DOScale(1f, slideDuration * 0.9f).SetEase(Ease.OutSine);
        }

        float t = 0f, dur = slideDuration + 0.02f;
        while (t < dur) { t += Time.unscaledDeltaTime; yield return null; }
        if (curRT) curRT.gameObject.SetActive(false);
        animating = false;
    }

    void OnConfirm()
    {
        if (idx < 0 || idx >= characters.Count) return;
        var chosen = characters[idx];

        // 1) Set karakter untuk runtime (dipakai di scene gameplay)
        CharacterPowerManager.Instance?.SetCharacter(chosen);

        // 2) Persist ke save: simpan KEY karakter yang dipilih.
        //    Kita pakai nama asset sebagai key supaya tidak perlu field 'id'.
        if (SaveManager.I != null && chosen != null)
        {
            string key = chosen.name;                  // <-- gunakan nama asset
            SaveManager.I.SetChosenCharacter(key);     // method ini juga langsung menyimpan ke disk
        }

        // 3) SFX & pindah scene gameplay
        if (!string.IsNullOrEmpty(sfxConfirmKey)) AudioManager.I?.PlayUI(sfxConfirmKey);
        if (!string.IsNullOrEmpty(gameplaySceneName)) SceneTransition.LoadScene(gameplaySceneName);
    }
}
