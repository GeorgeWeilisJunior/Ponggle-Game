using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

[RequireComponent(typeof(Image))]
public class UIPulseImage : MonoBehaviour
{
    [Header("Scale Pulse")]
    [SerializeField] float scaleMin = 0.96f;
    [SerializeField] float scaleMax = 1.04f;
    [SerializeField] float period = 1.8f;

    [Header("Fade (optional)")]
    [SerializeField, Range(0f, 1f)] float alphaMin = 0.75f;
    [SerializeField, Range(0f, 1f)] float alphaMax = 1.00f;

    Image img; Sequence seq;

    void Awake() { img = GetComponent<Image>(); }

    void OnEnable()
    {
        seq?.Kill();
        transform.localScale = Vector3.one * scaleMin;
        var c = img.color; c.a = alphaMax; img.color = c;

        seq = DOTween.Sequence()
            .Append(transform.DOScale(scaleMax, period * 0.5f).SetEase(Ease.InOutSine))
            .Join(img.DOFade(alphaMax, period * 0.5f))
            .Append(transform.DOScale(scaleMin, period * 0.5f).SetEase(Ease.InOutSine))
            .Join(img.DOFade(alphaMin, period * 0.5f))
            .SetLoops(-1);
    }

    void OnDisable() { seq?.Kill(); }
}
