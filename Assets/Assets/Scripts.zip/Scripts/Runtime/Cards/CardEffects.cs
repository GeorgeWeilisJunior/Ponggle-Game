﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// Mengaktifkan efek kartu yang dipilih di Card Management untuk level saat ini.
/// Dibaca di GameManager.StartLevel() → ApplyPickedEffectsFromSave().
/// </summary>
public class CardEffects : MonoBehaviour
{
    public static CardEffects I { get; private set; }

    // --- Auto-bootstrap: selalu ada tanpa perlu GO di scene ---
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Bootstrap()
    {
        if (I != null) return;
        var go = new GameObject("CardEffects (Auto)");
        I = go.AddComponent<CardEffects>();
        DontDestroyOnLoad(go);
    }

    // ====== STATE COMMON CARDS ======
    public ElementType? firstShotElement { get; private set; }       // Flame/Water/Wind/Earth Infusion
    public int stoneBreakerRemaining { get; private set; } = 0;      // 2 hard pegs auto clear
    public float coinFreeBonus { get; private set; } = 0f;           // +0.25f => total 75%
    public float scoreBoostMultiplier { get; private set; } = 1f;    // 1.10f => +10% skor
    public float firstShotSpeedMultiplier { get; private set; } = 1f;// 1.10f => +10% speed tembakan 1
    public int freeBallThresholdDelta { get; private set; } = 0;     // -2 threshold
    public int killZoneBonusScore { get; private set; } = 0;         // +1000 saat mati oleh kill-zone

    // ====== STATE RARE CARDS ======
    /// <summary>Jumlah tembakan yang masih mendapatkan bucket kedua. Tiap kartu = +2 shot.</summary>
    public int doubleBucketShotsRemaining { get; private set; } = 0;
    public int saviorCharges { get; private set; } = 0;
    
    bool _appliedToScoreMgr = false;

    void Awake()
    {
        if (I && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
        ResetAll();
    }

    public void ResetAll()
    {
        firstShotElement = null;
        stoneBreakerRemaining = 0;
        coinFreeBonus = 0f;
        scoreBoostMultiplier = 1f;
        firstShotSpeedMultiplier = 1f;
        freeBallThresholdDelta = 0;
        killZoneBonusScore = 0;

        doubleBucketShotsRemaining = 0;
        saviorCharges = 0;

        _appliedToScoreMgr = false;
    }

    // ====== APPLY FROM SAVE ======
    /// <summary>Dipanggil GameManager.StartLevel()</summary>
    public void ApplyPickedEffectsFromSave()
    {
        ResetAll();

        var pickedIds = SaveManager.I ? SaveManager.I.Data.pickedForNext : null;
        if (pickedIds == null || pickedIds.Count == 0) return;

        string Norm(string s) => string.IsNullOrWhiteSpace(s)
            ? ""
            : new string(s.Where(ch => !char.IsWhiteSpace(ch)).ToArray()).ToLowerInvariant();

        foreach (var id in pickedIds)
        {
            var cd = CardLibrary.GetById(id);
            if (!cd) continue;

            var key = Norm(cd.effectKey);

            switch (key)
            {
                // --- Element Infusions: pakai yang pertama saja ---
                case "flameinfusion":
                case "waterinfusion":
                case "windinfusion":
                case "earthinfusion":
                    if (!firstShotElement.HasValue)
                    {
                        firstShotElement = key switch
                        {
                            "flameinfusion" => ElementType.Fire,
                            "waterinfusion" => ElementType.Water,
                            "windinfusion" => ElementType.Wind,
                            _ => ElementType.Earth,
                        };
                    }
                    break;

                case "stonebreaker": stoneBreakerRemaining += 2; break;
                case "luckyball": coinFreeBonus += 0.25f; break;
                case "scorebooster": scoreBoostMultiplier *= 1.10f; break;
                case "fasterball": firstShotSpeedMultiplier *= 1.10f; break;
                case "softtouch": freeBallThresholdDelta -= 2; break;

                // izinkan dua ejaan
                case "betterkillzone":
                case "betterkill-zone": killZoneBonusScore += 1000; break;

                // ====== RARE ======
                case "doublebucket":
                    // Tiap kartu menambah 2 tembakan berkah "bucket kedua"
                    doubleBucketShotsRemaining += 2;
                    break;
                case "savior":
                    saviorCharges += 3;              // tiap kartu menambah 3x penyelamatan
                    break;
            }
        }

        // Terapkan element untuk tembakan pertama (memicu NextBallUI)
        if (firstShotElement.HasValue)
            ElementSystem.SetNext(firstShotElement.Value);

        // Multiplier skor global
        ScoreManager.SetGlobalScoreMultiplier(scoreBoostMultiplier > 1f ? scoreBoostMultiplier : 1f);
        _appliedToScoreMgr = scoreBoostMultiplier > 1f;

#if UNITY_EDITOR
        Debug.Log($"[CardEffects] Applied → elem={firstShotElement}, stoneBreaker={stoneBreakerRemaining}, " +
                  $"coin+={coinFreeBonus}, scoreMul={scoreBoostMultiplier}, speed1st={firstShotSpeedMultiplier}, " +
                  $"freeBallΔ={freeBallThresholdDelta}, kill+={killZoneBonusScore}, " +
                  $"doubleBucketShots={doubleBucketShotsRemaining}");
#endif
    }

    // ====== HOOKS dipanggil subsistem lain ======

    /// <summary>GameManager.UseBall() → setelah shotsTaken++</summary>
    public void AfterFirstShotApplied()
    {
        // Reset ke netral SETELAH peluru pertama sudah pakai infusion
        if (firstShotElement.HasValue)
        {
            firstShotElement = null;
            ElementSystem.SetNext(ElementType.Neutral);
        }
    }

    /// <summary>GameManager.RegisterHitPeg(...) untuk auto-clear hard peg (Stone Breaker).</summary>
    public bool TryConsumeStoneBreakerFor(PegController peg)
    {
        if (stoneBreakerRemaining <= 0) return false;
        if (peg == null || !peg.IsHard) return false;

        stoneBreakerRemaining--;
        return true; // caller silakan paksa clear
    }

    /// <summary>Dipanggil KillZone/BallController saat bola mati oleh kill-zone.</summary>
    public void OnBallKilledByKillZone()
    {
        if (killZoneBonusScore <= 0) return;

        // Masukkan ke antrean (aman kalau ada sistem lain yang baca)
        GameManager.Instance?.QueueKillZoneBonus(killZoneBonusScore);

        // ✅ tapi langsung bayar sekarang supaya HUD naik saat itu juga
        GameManager.Instance?.ApplyKillZoneBonusNow();
    }

    /// <summary>
    /// Dipanggil di awal setiap tembakan. Return true kalau DoubleBucket aktif untuk tembakan ini
    /// lalu menurunkan sisa shot.
    /// </summary>
    public bool ConsumeDoubleBucketForThisShot()
    {
        if (doubleBucketShotsRemaining <= 0) return false;
        doubleBucketShotsRemaining--;
        return true;
    }

    /// <summary>Consume 1 charge Savior jika masih ada. Return true jika terpakai.</summary>
    public bool TryConsumeSavior()
    {
        if (saviorCharges <= 0) return false;
        saviorCharges--;
        return true;
    }
}
