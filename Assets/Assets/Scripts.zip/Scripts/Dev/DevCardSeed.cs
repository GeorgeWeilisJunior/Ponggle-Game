using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Mempermudah testing Card Management & efek kartu tanpa alur _App.
/// - Mengisi Save dengan Owned cards (dari Resources)
/// - (Opsional) mengisi Picked untuk Next Level + set Energy
/// - (Opsional) auto-jump ke gameplay scene saat tombol Next ditekan
/// </summary>
[DefaultExecutionOrder(-800)] // SaveManager di -900 -> ini jalan setelah SaveManager siap
public class DevCardSeed : MonoBehaviour
{
    [Header("Owned Cards Seed")]
    [Tooltip("Kalau kosong, ambil SEMUA CardData di Resources/Cards/")]
    public string[] ownedCardIds = new string[0]; // isi dengan Id di CardData (bukan display name)

    [Header("Picked for Next (uji efek)")]
    public string[] pickedForNextIds = new string[0];
    public int energyLimit = 10;

    [Header("Optional")]
    [Tooltip("Nama scene gameplay untuk loncat setelah Next")]
    public string gameplaySceneName = "1-1"; // ganti sesuai nama scene pertamamu
    public bool autoJumpToGameplayOnNext = false;

    void Awake()
    {
        // Pastikan SaveManager ada (kalau kamu Play dari scene CardManagement)
        if (SaveManager.I == null)
        {
            var go = new GameObject("SaveManager (Debug)");
            go.AddComponent<SaveManager>(); // Awake SaveManager akan load/create data default
        }

        // 1) Seed Owned
        EnsureOwned();

        // 2) Seed Picked (opsional)
        if (pickedForNextIds != null && pickedForNextIds.Length > 0)
        {
            var list = pickedForNextIds.Distinct().ToList();
            SaveManager.I.SetPickedForNextLevel(list, Mathf.Max(energyLimit, 1));
        }

        // 3) (Opsional) Hook tombol Next agar loncat ke gameplay saat ditekan
        if (autoJumpToGameplayOnNext)
        {
            var ui = FindObjectOfType<CardManagementUI>();
            if (ui != null)
            {
                // Trik ringan: tambahkan listener ke tombol Next lewat SendMessage
                ui.gameObject.AddComponent<DevNextHook>().Init(gameplaySceneName);
            }
        }
    }

    void EnsureOwned()
    {
        // Ambil ID yang mau dimiliki
        List<string> ids = new();
        if (ownedCardIds != null && ownedCardIds.Length > 0)
        {
            ids.AddRange(ownedCardIds);
        }
        else
        {
            // Ambil semua CardData dari Resources/Cards
            var all = Resources.LoadAll<CardData>("Cards");
            foreach (var cd in all)
                if (cd && !string.IsNullOrEmpty(cd.id))
                    ids.Add(cd.id);
        }
        ids = ids.Distinct().ToList();

        // Masukkan ke save lewat buffer drop -> claim ke inventory
        foreach (var id in ids)
            SaveManager.I.AddDropToBuffer(id);
        SaveManager.I.ClaimDropsToInventory();
    }

    // Listener kecil untuk tombol NEXT (dipasang dinamis)
    class DevNextHook : MonoBehaviour
    {
        string _scene;
        public void Init(string sceneName) => _scene = sceneName;

        // Dipanggil CardManagementUI saat Next sukses (melewati SaveManager.SetPickedForNextLevel)
        // Kalau kamu ingin hook pasti, ganti jadi event publik di CardManagementUI dan panggil dari sana.
        void OnEnable() { SceneManager.sceneLoaded += OnSceneLoaded; }
        void OnDisable() { SceneManager.sceneLoaded -= OnSceneLoaded; }

        void OnSceneLoaded(Scene s, LoadSceneMode m)
        {
            // NOP: contoh placeholder kalau kamu mau otomatis navigasi
        }

        // Kamu bisa panggil ini manual dari Button Next (OnClick) untuk testing:
        public void JumpNow()
        {
            if (!string.IsNullOrEmpty(_scene))
                SceneManager.LoadScene(_scene);
        }
    }
}
