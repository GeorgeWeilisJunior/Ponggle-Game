﻿using System;
using System.IO;
using System.Text;
using UnityEngine;

[DefaultExecutionOrder(-900)]
public class SaveManager : MonoBehaviour
{
    public static SaveManager I { get; private set; }

    public SaveData Data { get; private set; } = new SaveData();

    public bool HasSave => _cachedHasSave ?? File.Exists(SavePath);
    public bool RequestedContinue { get; private set; }
    public void ConsumeContinueRequest() => RequestedContinue = false;
    string SavePath => Path.Combine(Application.persistentDataPath, "savegame.json");
    bool? _cachedHasSave;

    [Header("Leaderboard")]
    [Tooltip("Key papan skor untuk run Adventure 25 level.")]
    [SerializeField] string leaderboardKey = "Adventure_All25";
    const int TOTAL_LEVELS = 25; // index 0..24

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);

        TryLoadFromDisk(); // kalau belum ada file, Data default
        Data.sessionsPlayed++;
        Data.lastPlayedAt = DateTime.UtcNow;
        SaveToDisk(); // commit meta

        TryPushTotalScoreToHUD();
    }

    /* ========================= PUBLIC API ========================= */

    // Dipanggil dari Name Entry (setelah user confirm nama)
    public void NewGame(string playerName)
    {
        Data = new SaveData();
        Data.playerName = playerName ?? "";
        Data.createdAt = DateTime.UtcNow;
        Data.lastPlayedAt = Data.createdAt;
        Data.sessionsPlayed = 1;

        // Progress awal
        Data.levelIndex = 0;
        Data.stageIndex = 0;
        Data.lives = 3;
        Data.totalScore = 0;

        // Default karakter kalau belum dipilih
        if (string.IsNullOrEmpty(Data.chosenCharacterId))
            Data.chosenCharacterId = "NesoNesaNesda";

        _cachedHasSave = true;
        SaveToDisk();
        TryPushTotalScoreToHUD();
    }

    // Dipanggil dari Main Menu → Load/Continue
    public void ContinueGame()
    {
        if (!HasSave) return;
        TryLoadFromDisk();
        RequestedContinue = true;           // ← tandai bahwa user klik Load/Continue
        TryPushTotalScoreToHUD();
        Debug.Log($"[Save] Continue requested. levelIndex={Data.levelIndex}");
    }


    // Kalau punya panel Name Entry terpisah
    public void SetPlayerName(string name)
    {
        Data.playerName = name ?? "";
        SaveToDisk();
    }

    /* ===== Karakter (API baru + alias lama) ===== */

    // === Nama baru yang dipakai CharacterPowerManager ===
    public void SetChosenCharacterKey(string key)
    {
        // normalisasi: kalau kosong, pakai default triple-shot
        Data.chosenCharacterId = string.IsNullOrEmpty(key) ? "NesoNesaNesda" : key;

        // sinkron legacy agar sistem lama masih bekerja
        Data.currentCharacter = Data.chosenCharacterId;

        SaveToDisk();
    }

    public string GetChosenCharacterKey()
    {
        // prioritas ke field baru; fallback ke legacy
        if (!string.IsNullOrEmpty(Data.chosenCharacterId)) return Data.chosenCharacterId;
        return string.IsNullOrEmpty(Data.currentCharacter) ? "NesoNesaNesda" : Data.currentCharacter;
    }

    // === Alias lama (tetap ada agar tidak merusak referensi lain) ===
    public void SetChosenCharacter(string key) => SetChosenCharacterKey(key);
    public string GetChosenCharacter() => GetChosenCharacterKey();

    public void DeleteSave()
    {
        try
        {
            if (File.Exists(SavePath)) File.Delete(SavePath);
            _cachedHasSave = false;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"DeleteSave failed: {e}");
        }
    }

    /* ---------- Dipanggil oleh gameplay ---------- */

    // Menang 1 level
    public void OnLevelCompleted(int nextLevelIndex, int totalScore, int ballsLeft)
    {
        Data.totalScore = totalScore;
        Data.ballsLeft = ballsLeft;

        bool finishedAll = nextLevelIndex >= TOTAL_LEVELS;

        if (finishedAll)
        {
            SubmitLeaderboardWin();
            AddRunHistory("Win", Data.totalScore);

            Data.gameClearedOnce = true;
            Data.porkyUnlocked = true;

            // Reset run baru
            Data.levelIndex = 0;
            Data.stageIndex = 0;
            Data.lives = 3;
            Data.totalScore = 0;
            Data.pickedForNext.Clear();
        }
        else
        {
            Data.levelIndex = Mathf.Clamp(nextLevelIndex, 0, 999);
            Data.stageIndex = Data.levelIndex / 5;
            Data.pickedForNext.Clear();

            if (!Data.fastForwardUnlocked && nextLevelIndex >= 5)
                Data.fastForwardUnlocked = true;
        }

        Data.lastPlayedAt = DateTime.UtcNow;
        SaveToDisk();
        TryPushTotalScoreToHUD();
    }

    // Kalah 1 level
    public void OnLevelFailed(int keepLevelIndexIfRetry)
    {
        Data.lives = Mathf.Max(0, Data.lives - 1);

        Data.levelIndex = keepLevelIndexIfRetry;
        Data.stageIndex = Data.levelIndex / 5;

        if (Data.lives <= 0)
        {
            // Game Over untuk stage ini → kembali ke awal stage
            int stageStart = Data.stageIndex * 5;
            Data.levelIndex = stageStart;
            Data.stageIndex = Data.levelIndex / 5;
            Data.lives = 3;

            // Desainmu: reset skor perjalanan
            Data.totalScore = 0;

            AddRunHistory("Lose", 0);
        }

        Data.lastPlayedAt = DateTime.UtcNow;
        SaveToDisk();
        TryPushTotalScoreToHUD();
    }

    /* ========================= CARDS ========================= */

    public void AddDropToBuffer(string cardId)
    {
        if (string.IsNullOrEmpty(cardId)) return;
        if (!Data.droppedBuffer.Contains(cardId))
            Data.droppedBuffer.Add(cardId);
        SaveToDisk();
    }

    public void ClaimDropsToInventory()
    {
        foreach (var c in Data.droppedBuffer)
            if (!Data.ownedCards.Contains(c))
                Data.ownedCards.Add(c);
        Data.droppedBuffer.Clear();
        SaveToDisk();
    }

    public void SetPickedForNextLevel(System.Collections.Generic.List<string> picked, int totalEnergyLimit)
    {
        Data.pickedForNext = picked != null
            ? new System.Collections.Generic.List<string>(picked)
            : new System.Collections.Generic.List<string>();
        Data.energyLimit = totalEnergyLimit;
        SaveToDisk();
    }

    /* ========================= INTERNALS ========================= */

    void SubmitLeaderboardWin()
    {
        try
        {
            LocalLeaderboardManager.I?.Submit(leaderboardKey, Data.playerName, Data.totalScore);
        }
        catch (Exception e)
        {
            Debug.LogWarning($"SubmitLeaderboardWin failed: {e}");
        }
    }

    void AddRunHistory(string result, int score)
    {
        try
        {
            Data.leaderboard.Add(new LeaderboardEntry(Data.playerName, score, result));
        }
        catch (Exception e)
        {
            Debug.LogWarning($"AddRunHistory failed: {e}");
        }
    }

    void TryPushTotalScoreToHUD()
    {
        try
        {
            ScoreManager.SetTotalScore(Mathf.Max(0, Data.totalScore));
        }
        catch { /* scene belum punya ScoreManager; skip */ }
    }

    void TryLoadFromDisk()
    {
        try
        {
            if (!File.Exists(SavePath)) { _cachedHasSave = false; return; }
            var json = File.ReadAllText(SavePath, Encoding.UTF8);
            var loaded = JsonUtility.FromJson<SaveData>(json);
            if (loaded != null) Data = loaded;

            // Backward-compat: isi chosenCharacterId bila kosong
            if (string.IsNullOrEmpty(Data.chosenCharacterId))
            {
                if (!string.IsNullOrEmpty(Data.currentCharacter))
                    Data.chosenCharacterId = Data.currentCharacter;
                else
                    Data.chosenCharacterId = "NesoNesaNesda";
            }

            _cachedHasSave = true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Load failed: {e}");
            _cachedHasSave = false;
        }
    }

    public void SaveToDisk()
    {
        try
        {
            Data.lastPlayedAt = DateTime.UtcNow;
            var json = JsonUtility.ToJson(Data, false);
            File.WriteAllText(SavePath, json, Encoding.UTF8);
            _cachedHasSave = true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Save failed: {e}");
        }
    }

    // Legacy helper: tetap ada agar tidak memutus referensi lama
    public void SetSelectedCharacterIndex(int idx)
    {
        Data.selectedCharacterIndex = Mathf.Max(0, idx);
        SaveToDisk();
    }

    public int GetSelectedCharacterIndex() => Mathf.Max(0, Data.selectedCharacterIndex);
}
