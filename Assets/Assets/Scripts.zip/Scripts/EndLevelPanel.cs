﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

[DisallowMultipleComponent]
public class EndLevelPanel : MonoBehaviour
{
    /* ───────── Public API ───────── */
    public enum EndState { Win, Lose }

    /* ───────── State Flow ───────── */
    enum Stage { Summary, AfterCardDrop }
    Stage stage = Stage.Summary;
    EndState endState = EndState.Win;

    bool subscribed;
    bool hasPendingStats;
    LevelStats pendingStats;

    /* ───────── Inspector ───────── */
    [Header("Canvas / Visual Root (drag: PanelRoot)")]
    [SerializeField] GameObject canvasGO;

    [Header("Header")]
    [Tooltip("Opsional: kalau masih pakai TMP untuk judul, isi ini. Kalau judul full image, biarkan kosong.")]
    [SerializeField] TMP_Text titleText;      // optional
    [SerializeField] Image headerBG;          // strip biru belakang judul (optional)
    [SerializeField] Color winColor = new Color(0.19f, 0.45f, 0.98f);
    [SerializeField] Color loseColor = new Color(0.75f, 0.22f, 0.30f);

    [Header("Header (Title Images)")]
    [Tooltip("GameObject gambar judul WIN (mis. 'LEVEL COMPLETE!').")]
    [SerializeField] GameObject titleWinGO;
    [Tooltip("GameObject gambar judul LOSE (mis. 'YOU LOSE').")]
    [SerializeField] GameObject titleLoseGO;

    [Header("Stat Texts")]
    [SerializeField] TMP_Text totalTxt;
    [SerializeField] TMP_Text levelTxt;
    [SerializeField] TMP_Text winTxt;
    [SerializeField] TMP_Text shotsTxt;
    [SerializeField] TMP_Text freeTxt;
    [SerializeField] TMP_Text pctTxt;
    [SerializeField] TMP_Text shotPtsTxt;
    [SerializeField] TMP_Text feverPtsTxt;

    [Header("Buttons")]
    [SerializeField] Button nextBtn;
    [SerializeField] Button retryBtn;
    [SerializeField] Button backBtn;          // opsional (ke menu/map)

    [Header("Next Button (Label Images)")]
    [Tooltip("Label gambar untuk state 'Open Reward' (saat summary WIN, sebelum CardDrop).")]
    [SerializeField] GameObject nextLabelOpenRewardGO;
    [Tooltip("Label gambar untuk state 'Next Level' (setelah CardDrop).")]
    [SerializeField] GameObject nextLabelNextLevelGO;

    [Header("Card Drop Hook")]
    [SerializeField] CardDropPanel cardDropPanel;   // drag CardDropPanel di scene

    [Header("Visuals")]
    [SerializeField] Image darkenBG;
    [SerializeField] float popDuration = 0.4f;
    [SerializeField] int sortingOrder = 50; // panel selalu di depan

    /* ───────── Lifecycle ───────── */
    void Awake()
    {
        if (canvasGO) canvasGO.SetActive(false);

        var cv = GetComponent<Canvas>();
        if (cv) cv.sortingOrder = sortingOrder;
    }

    void Start()
    {
        // Subscribe Win dari GameManager (auto)
        if (GameManager.Instance != null)
        {
            GameManager.Instance.onLevelSuccess += Show; // event Win lama
            subscribed = true;
        }
        else
        {
            Debug.LogWarning("[EndLevelPanel] GameManager.Instance null di Start().");
        }

        // Tombol
        if (nextBtn) nextBtn.onClick.AddListener(OnClickNext);
        if (retryBtn) retryBtn.onClick.AddListener(OnClickRetry);
        if (backBtn) backBtn.onClick.AddListener(() => { Resume(); LevelManager.Instance.BackToMenu(); });
    }

    void OnDestroy()
    {
        if (subscribed && GameManager.Instance != null)
            GameManager.Instance.onLevelSuccess -= Show;
    }

    /* ───────── Entry Points ─────────
       Dipanggil GameManager saat KEMENANGAN (event lama) */
    void Show(LevelStats s)
    {
        hasPendingStats = true;
        pendingStats = s;
        stage = Stage.Summary;
        endState = EndState.Win;

        DoShow(pendingStats);
        SetHeaderVisuals();

        // Win summary: Next → Open Reward
        if (nextBtn) nextBtn.gameObject.SetActive(true);
        if (retryBtn) retryBtn.gameObject.SetActive(true);
        SetNextButtonLabel(isOpenReward: true);
    }

    // Dipanggil GameManager saat KEKALAHAN (bola habis & masih ada orange)
    public void ShowLose(LevelStats s)
    {
        hasPendingStats = true;
        pendingStats = s;
        stage = Stage.Summary;
        endState = EndState.Lose;

        DoShow(pendingStats);
        SetHeaderVisuals();

        // Lose: tidak ada CardDrop, sembunyikan Next
        if (nextBtn) nextBtn.gameObject.SetActive(false);
        if (retryBtn) retryBtn.gameObject.SetActive(true);
    }

    // Dipanggil CardDropPanel setelah proses drop selesai → tampilkan kembali end panel (Win)
    public void ShowPending()
    {
        if (!hasPendingStats) return;

        stage = Stage.AfterCardDrop;
        // Tampilkan kembali panel end (tetap pause)
        DoShow(pendingStats);

        endState = EndState.Win; // setelah drop tetap Win
        SetHeaderVisuals();

        if (nextBtn) nextBtn.gameObject.SetActive(true);
        if (retryBtn) retryBtn.gameObject.SetActive(true);
        SetNextButtonLabel(isOpenReward: false); // jadi "Next Level"
    }

    /* ───────── Button Handlers ───────── */
    void OnClickNext()
    {
        if (endState == EndState.Lose) return; // safety

        if (stage == Stage.Summary)
        {
            // Buka Card Drop (tetap pause; CardDrop pakai unscaled time)
            if (canvasGO) canvasGO.SetActive(false);

            if (!cardDropPanel)
                cardDropPanel = FindObjectOfType<CardDropPanel>(true);

            if (cardDropPanel)
            {
                cardDropPanel.BeginFromWin(); // CardDrop akan memanggil ShowPending() saat selesai
            }
            else
            {
                // Fallback: kalau CardDrop tidak ada, langsung Next Level
                Resume();
                LevelManager.Instance.LoadNext();
            }
            return;
        }

        // Setelah Card Drop selesai → lanjut level berikutnya
        Resume();
        LevelManager.Instance.LoadNext();
    }

    void OnClickRetry()
    {
        Time.timeScale = 1f;

        int targetIndex = LevelManager.Instance != null ? LevelManager.Instance.CurrentIndex : 0;

        if (SaveManager.I != null)
        {
            int savedIndex = SaveManager.I.Data.levelIndex;
            if (savedIndex != targetIndex) // berarti sudah di-reset ke awal stage
            {
                LevelManager.Instance.LoadLevelIndex(savedIndex);
                return;
            }
        }
        LevelManager.Instance.Restart();
    }



    /* ───────── Internal Render ───────── */
    void DoShow(LevelStats s)
    {
        // Isi label angka
        if (totalTxt) totalTxt.text = s.totalScore.ToString("N0");
        if (levelTxt) levelTxt.text = s.levelScore.ToString("N0");
        if (winTxt) winTxt.text = s.winOnFirstTry ? "YES" : "NO";
        if (shotsTxt) shotsTxt.text = s.shotsTaken.ToString();
        if (freeTxt) freeTxt.text = s.freeBalls.ToString();
        if (pctTxt) pctTxt.text = (s.percentCleared * 100f).ToString("0") + "%";
        if (shotPtsTxt) shotPtsTxt.text = s.shotPoints.ToString("N0");
        if (feverPtsTxt) feverPtsTxt.text = s.feverPoints.ToString("N0");

        if (canvasGO) canvasGO.SetActive(true);

        // Matikan tween lama
        transform.DOKill();
        if (darkenBG) darkenBG.DOKill();

        // Reset awal
        transform.localScale = Vector3.zero;
        if (darkenBG)
        {
            var c = darkenBG.color; c.a = 0f; darkenBG.color = c;
        }

        // Tween dengan unscaled time (karena Time.timeScale = 0 saat panel tampil)
        transform.DOScale(1f, popDuration).SetEase(Ease.OutBack).SetUpdate(true);
        if (darkenBG) darkenBG.DOFade(1f, popDuration).SetUpdate(true);

        // SFX + Pause
        if (AudioManager.I)
            AudioManager.I.Play(endState == EndState.Win ? "TaDa" : "Lose", Camera.main.transform.position);
        Time.timeScale = 0f;
    }

    void SetHeaderVisuals()
    {
        // Jika masih ada TMP judul, isi. Kalau tidak, biarkan kosong.
        if (titleText)
            titleText.text = (endState == EndState.Win) ? "LEVEL COMPLETE!" : "YOU LOSE";

        if (headerBG)
            headerBG.color = (endState == EndState.Win) ? winColor : loseColor;

        // ON/OFF judul gambar
        if (titleWinGO) titleWinGO.SetActive(endState == EndState.Win);
        if (titleLoseGO) titleLoseGO.SetActive(endState == EndState.Lose);
    }

    void SetNextButtonLabel(bool isOpenReward)
    {
        // Toggle label gambar di tombol Next
        if (nextLabelOpenRewardGO) nextLabelOpenRewardGO.SetActive(isOpenReward);
        if (nextLabelNextLevelGO) nextLabelNextLevelGO.SetActive(!isOpenReward);
    }

    /* ───────── Helpers ───────── */
    void Resume() => Time.timeScale = 1f;
}
