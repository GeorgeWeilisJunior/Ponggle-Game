﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[DefaultExecutionOrder(-200)]
public class PegRandomizer : MonoBehaviour
{
    // ===== Coordination with Intro =====
    public static bool IsRandomizing { get; private set; }
    public static bool HasRunThisScene { get; private set; }
    public static int LastRunFrame { get; private set; } = -1;
    public static System.Action OnRandomizeDone;

    [Header("What to Randomize")]
    [SerializeField] bool randomizeOrange = true;
    [SerializeField] bool randomizeGreen = true;

    [Header("When")]
    [SerializeField] bool runOnStart = true;
    [SerializeField, Min(0)] int waitFramesBeforeRun = 1;

    [Header("Safety")]
    [Tooltip("Kandidat Blue harus di parent yang sama.")]
    [SerializeField] bool onlySwapWithinSameParent = true;

    [Tooltip("Kandidat Blue harus punya PegSwapGroup.group yang sama (dengan fallback kompatibel opsional).")]
    [SerializeField] bool onlySwapWithinSameGroup = true;

    [Tooltip("Jika aktif, kandidat Blue harus dari keluarga bentuk (Rounded/Brick/…) yang sama.")]
    [SerializeField] bool requireSameFamily = true;

    [Tooltip("Izinkan fallback group kompatibel ketika group identik tidak ada (lihat mapping).")]
    [SerializeField] bool allowCompatibleFallback = true;

    [Tooltip("Swap juga rotasi.")]
    [SerializeField] bool swapRotation = true;

    [Tooltip("Selalu swap scale bila kedua peg satu keluarga bentuk (aman untuk arc).")]
    [SerializeField] bool swapScaleIfSameFamily = true;

    [Header("Exclude Groups")]
    [Tooltip("Abaikan peg dengan group Hard dari proses randomize (disarankan untuk menjaga arc brick).")]
    [SerializeField] bool excludeHard = true;

    [Header("Debug")]
    [SerializeField] bool logWhenNoCandidate = false;

    void OnEnable()
    {
        IsRandomizing = false;
    }

    void Start()
    {
        if (!runOnStart) return;
        StartCoroutine(RunAfterFrames(waitFramesBeforeRun));
    }

    IEnumerator RunAfterFrames(int frames)
    {
        while (PegIntroPop.IsIntroPlaying) yield return null;
        for (int i = 0; i < frames; i++) yield return null;
        TryRandomize();
    }

    [ContextMenu("Randomize Now")]
    public void TryRandomize()
    {
        if (IsRandomizing) return;
        if (HasRunThisScene && LastRunFrame == Time.frameCount) return;
        if (PegIntroPop.IsIntroPlaying) return;

        IsRandomizing = true;

        var all = FindObjectsOfType<PegController>(true)
            .Where(p => p != null && p.gameObject.activeInHierarchy)
            .Where(p => p.State != PegController.PegState.Cleared)
            .ToList();

        if (all.Count == 0) { Done(); return; }

        var blues = all.Where(p => p.Type == PegType.Blue).ToList();
        var oranges = all.Where(p => p.Type == PegType.Orange).ToList();
        var greens = all.Where(p => p.Type == PegType.Green).ToList();

        PegSwapGroupId GetGroup(Transform t)
        {
            var g = t.GetComponent<PegSwapGroup>() ?? t.GetComponentInParent<PegSwapGroup>();
            return g ? g.group : PegSwapGroupId.Normal;
        }

        // === FAMILY SUPPORT ===
        PegFamily GetFamily(Transform t)
        {
            var tag = t.GetComponent<PegFamilyTag>() ?? t.GetComponentInParent<PegFamilyTag>();
            if (tag) return tag.family;

            string n = t.name.ToLowerInvariant();
            PegFamily f = PegFamily.Unknown;
            if (n.Contains("moreroundedbrick") || n.Contains("more_rounded_brick")) f = PegFamily.MoreRoundedBrick;
            else if (n.Contains("roundedbrick") || n.Contains("rounded_brick")) f = PegFamily.RoundedBrick;
            else if (n.Contains("brick")) f = PegFamily.Brick;
            else if (n.Contains("round")) f = PegFamily.Rounded;

            var add = t.gameObject.AddComponent<PegFamilyTag>();
            add.family = f;
            return f;
        }

        bool SameParent(Transform a, Transform b) => a.parent == b.parent;

        // Fallback prioritas untuk group khusus
        List<PegSwapGroupId> GetCompatibleGroups(PegSwapGroupId g)
        {
            var list = new List<PegSwapGroupId> { g };
            if (!allowCompatibleFallback || !onlySwapWithinSameGroup) return list;

            switch (g)
            {
                case PegSwapGroupId.AntiGravityAndDisappearing:
                    list.Add(PegSwapGroupId.AntiGravity);
                    list.Add(PegSwapGroupId.Disappearing);
                    list.Add(PegSwapGroupId.Normal);
                    break;
                case PegSwapGroupId.AntiGravity:
                    list.Add(PegSwapGroupId.AntiGravityAndDisappearing);
                    list.Add(PegSwapGroupId.Normal);
                    break;
                case PegSwapGroupId.Disappearing:
                    list.Add(PegSwapGroupId.AntiGravityAndDisappearing);
                    list.Add(PegSwapGroupId.Normal);
                    break;
            }
            return list;
        }

        // === Helpers ===
        System.Random rng = new System.Random();
        void Shuffle<T>(IList<T> list)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int k = rng.Next(i + 1);
                (list[i], list[k]) = (list[k], list[i]);
            }
        }

        void SwapTransform(Transform a, Transform b, bool forceSwapScale)
        {
            Vector3 posA = a.position, posB = b.position;
            Quaternion rotA = a.rotation, rotB = b.rotation;
            Vector3 scaleA = a.localScale, scaleB = b.localScale;

            a.position = posB; b.position = posA;
            if (swapRotation) { a.rotation = rotB; b.rotation = rotA; }
            if (forceSwapScale) { a.localScale = scaleB; b.localScale = scaleA; }
        }

        bool IsExcludedByGroup(Transform t)
        {
            var g = GetGroup(t);
            if (excludeHard && g == PegSwapGroupId.Hard) return true;
            return false;
        }

        // Kandidat Blue per target (batasi parent + group + family, dan exclude group tertentu)
        List<PegController> GetBlueCandidatesFor(PegController target, HashSet<PegController> alreadyTaken, out bool sameFamilyWillSwapScale)
        {
            var targetGroup = GetGroup(target.transform);
            var targetFamily = GetFamily(target.transform);

            sameFamilyWillSwapScale = false;

            IEnumerable<PegController> q = blues.Where(b => !alreadyTaken.Contains(b))
                                                .Where(b => !IsExcludedByGroup(b.transform));

            if (IsExcludedByGroup(target.transform))
                return new List<PegController>(); // target sendiri dikecualikan → jangan diacak

            if (onlySwapWithinSameParent)
                q = q.Where(b => SameParent(target.transform, b.transform));

            if (requireSameFamily)
            {
                q = q.Where(b => GetFamily(b.transform) == targetFamily);
                sameFamilyWillSwapScale = true; // aman tukar scale
            }

            if (onlySwapWithinSameGroup)
            {
                var prio = GetCompatibleGroups(targetGroup);
                foreach (var g in prio)
                {
                    var bucket = q.Where(b => GetGroup(b.transform) == g).ToList();
                    if (bucket.Count > 0) return bucket;
                }
                return new List<PegController>();
            }

            return q.ToList();
        }

        // ORANGE
        if (randomizeOrange && oranges.Count > 0)
        {
            Shuffle(oranges);
            var taken = new HashSet<PegController>();
            foreach (var o in oranges)
            {
                bool willSwapScale;
                var cands = GetBlueCandidatesFor(o, taken, out willSwapScale);
                if (cands.Count == 0)
                {
                    if (logWhenNoCandidate)
                        Debug.Log($"[PegRandomizer] No BLUE candidate for ORANGE '{o.name}' (group={GetGroup(o.transform)}, family={GetFamily(o.transform)})");
                    continue;
                }
                Shuffle(cands);
                var chosen = cands[0];
                taken.Add(chosen);

                bool forceScale = swapScaleIfSameFamily && willSwapScale;
                SwapTransform(o.transform, chosen.transform, forceScale);
            }
        }

        // GREEN
        if (randomizeGreen && greens.Count > 0)
        {
            var taken = new HashSet<PegController>();
            foreach (var g in greens.OrderBy(_ => rng.Next()))
            {
                bool willSwapScale;
                var cands = GetBlueCandidatesFor(g, taken, out willSwapScale);
                if (cands.Count == 0)
                {
                    if (logWhenNoCandidate)
                        Debug.Log($"[PegRandomizer] No BLUE candidate for GREEN '{g.name}' (group={GetGroup(g.transform)}, family={GetFamily(g.transform)})");
                    continue;
                }
                Shuffle(cands);
                var chosen = cands[0];
                taken.Add(chosen);

                bool forceScale = swapScaleIfSameFamily && willSwapScale;
                SwapTransform(g.transform, chosen.transform, forceScale);
            }
        }

        Done();
    }

    void Done()
    {
        IsRandomizing = false;
        HasRunThisScene = true;
        LastRunFrame = Time.frameCount;
        OnRandomizeDone?.Invoke();
    }
}
