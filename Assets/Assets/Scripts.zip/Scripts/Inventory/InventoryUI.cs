﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryUI : MonoBehaviour
{
    [Serializable]
    public class CardEntry
    {
        public ScriptableObject data; // CardData
        public string id;
        public Sprite art;
        public bool owned = false;
        public CardRarity rarity = CardRarity.Common; // <-- pakai enum global, bukan enum lokal
    }

    [Header("Refs")]
    [SerializeField] Image detailImage;
    [SerializeField] Transform content;
    [SerializeField] GameObject cardTilePrefab;
    [SerializeField] ScrollRect scrollRect;

    [Header("Sorting Mode")]
    [SerializeField, Tooltip("OFF: rarity -> owned -> id. ON: owned -> rarity -> id")]
    bool ownedFirstGlobally = false;

    [Header("Audio (keys)")]
    [SerializeField] string sfxOpenKey = "InvOpen";
    [SerializeField] string sfxCloseKey = "InvClose";
    [SerializeField] string sfxClickKey = "InvCardClick";

    [Header("Overlay Music")]
    [Tooltip("Key BGM khusus inventory (lihat AudioManager > Music Tracks).")]
    [SerializeField] string overlayMusicKey = "Music_Inventory";
    [Tooltip("Pause BGM gameplay saat inventory terbuka lalu resume saat ditutup.")]
    [SerializeField] bool pauseGameplayMusic = true;

    [Header("Scroll Tuning")]
    [SerializeField, Range(10f, 200f)] float mouseWheelSensitivity = 120f;

    readonly List<GameObject> spawned = new();
    readonly List<CardEntry> library = new();  // dibangun runtime dari Resources + Save
    float prevTimeScale = 1f;
    bool gameplayWasPlaying;

    void OnEnable()
    {
        // Pause gameplay
        prevTimeScale = Time.timeScale;
        Time.timeScale = 0f;
        Launcher.Instance?.LockInput();

        // SFX & Music
        AudioManager.I?.PlayUI(sfxOpenKey, ignorePause: true);
        if (pauseGameplayMusic && AudioManager.I != null) { gameplayWasPlaying = AudioManager.I.IsMusicPlaying; AudioManager.I.PauseMusic(); }
        if (!string.IsNullOrEmpty(overlayMusicKey)) AudioManager.I?.PlayOverlayMusic(overlayMusicKey, true);

        if (scrollRect)
        {
            scrollRect.horizontal = false;
            scrollRect.vertical = true;
            scrollRect.movementType = ScrollRect.MovementType.Clamped;
            scrollRect.scrollSensitivity = mouseWheelSensitivity;
            scrollRect.onValueChanged.AddListener(OnScrollRectChanged);
        }

        // === Build dari Resources + Save ===
        RebuildLibraryFromSave();

        NormalizeAndSortLibrary();
        BuildGrid();
        if (scrollRect) scrollRect.verticalNormalizedPosition = 1f;

        var picked = library.Find(e => e.owned && e.art != null) ?? library.Find(e => e.art != null);
        ShowDetail(picked?.art);
        ForceVerticalOnly();
    }

    void OnDisable()
    {
        AudioManager.I?.PlayUI(sfxCloseKey, ignorePause: true);
        AudioManager.I?.StopOverlayMusic();
        if (pauseGameplayMusic && AudioManager.I != null && gameplayWasPlaying) AudioManager.I.ResumeMusic();

        if (scrollRect) scrollRect.onValueChanged.RemoveListener(OnScrollRectChanged);

        Time.timeScale = prevTimeScale;
        Launcher.Instance?.UnlockInput();
    }

    // =============================================================

    void RebuildLibraryFromSave()
    {
        library.Clear();

        // 1) Ambil semua CardData dari Resources/Cards
        CardLibrary.EnsureCache(); // jika kamu punya cache, aman dibiarkan
        var all = Resources.LoadAll<CardData>("Cards");

        // 2) Ambil daftar owned dari Save
        var ownedIds = (SaveManager.I != null) ? SaveManager.I.Data.ownedCards : null;

        foreach (var c in all)
        {
            if (!c) continue;
            library.Add(new CardEntry
            {
                data = c,
                id = c.id,
                art = c.fullCardSprite ? c.fullCardSprite : c.icon,
                rarity = c.rarity, // langsung pakai enum global
                owned = ownedIds != null && ownedIds.Contains(c.id),
            });
        }
    }

    void OnScrollRectChanged(Vector2 _) => ForceVerticalOnly();
    void LateUpdate() => ForceVerticalOnly();

    void ForceVerticalOnly()
    {
        if (!scrollRect || !content) return;
        var rt = content as RectTransform;
        if (rt && Mathf.Abs(rt.anchoredPosition.x) > 0.01f)
            rt.anchoredPosition = new Vector2(0f, rt.anchoredPosition.y);
        if (Mathf.Abs(scrollRect.horizontalNormalizedPosition) > 0.0001f)
            scrollRect.horizontalNormalizedPosition = 0f;
        var v = scrollRect.velocity;
        if (Mathf.Abs(v.x) > 0.01f) { v.x = 0f; scrollRect.velocity = v; }
    }

    void NormalizeAndSortLibrary()
    {
        if (!ownedFirstGlobally)
            library.Sort((a, b) => {
                int r = a.rarity.CompareTo(b.rarity); if (r != 0) return r;   // Common<Rare<Epic<Legendary>
                int o = b.owned.CompareTo(a.owned); if (o != 0) return o;     // owned dulu
                return string.Compare(a.id, b.id, StringComparison.Ordinal);
            });
        else
            library.Sort((a, b) => {
                int o = b.owned.CompareTo(a.owned); if (o != 0) return o;
                int r = a.rarity.CompareTo(b.rarity); if (r != 0) return r;
                return string.Compare(a.id, b.id, StringComparison.Ordinal);
            });
    }

    void BuildGrid()
    {
        foreach (var go in spawned) if (go) Destroy(go);
        spawned.Clear();

        foreach (var entry in library)
        {
            if (entry.art == null) continue;
            var go = Instantiate(cardTilePrefab, content);
            spawned.Add(go);

            var img = go.GetComponent<Image>();
            var btn = go.GetComponent<Button>();

            if (img)
            {
                img.sprite = entry.art;
                img.preserveAspect = true;
                if (!entry.owned)
                {
                    img.color = new Color(1f, 1f, 1f, 0.4f);
                    var overlay = go.transform.Find("LockedOverlay");
                    if (overlay) overlay.gameObject.SetActive(true);
                    if (btn) btn.interactable = false;
                }
                else img.color = Color.white;
            }

            if (btn) btn.onClick.AddListener(() =>
            {
                ShowDetail(entry.art);
                AudioManager.I?.PlayUI(sfxClickKey, ignorePause: true);
            });
        }

        ResizeContentForGrid();
    }

    void ResizeContentForGrid()
    {
        var rt = content as RectTransform;
        var grid = content.GetComponent<GridLayoutGroup>();
        if (!rt || !grid || !scrollRect) return;

        int visibleCount = 0; foreach (var e in library) if (e.art != null) visibleCount++;
        int cols = Mathf.Max(1, grid.constraintCount);
        int rows = Mathf.CeilToInt(visibleCount / (float)cols);

        float h = grid.padding.top + rows * grid.cellSize.y + Mathf.Max(0, rows - 1) * grid.spacing.y + grid.padding.bottom;
        var vpH = ((RectTransform)scrollRect.viewport).rect.height;
        if (h < vpH) h = vpH + 1f;

        rt.sizeDelta = new Vector2(rt.sizeDelta.x, h);
        rt.anchoredPosition = new Vector2(0f, 0f);
    }

    void ShowDetail(Sprite s)
    {
        if (!detailImage) return;
        detailImage.sprite = s;
        detailImage.preserveAspect = true;
        detailImage.enabled = s != null;
    }
}
