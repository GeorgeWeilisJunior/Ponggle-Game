﻿using UnityEngine;
using static GameManager;

[RequireComponent(typeof(CapsuleCollider2D))]
public class BucketController : MonoBehaviour
{
    [Header("Gerak Normal")]
    [SerializeField] float speed = 2.5f;
    [SerializeField] float leftLimit = -8f;
    [SerializeField] float rightLimit = 8f;

    [Header("Collider & Visual")]
    [Tooltip("Trigger penangkap saat mode normal. Diubah jadi solid sementara saat Fireball.")]
    [SerializeField] CapsuleCollider2D normalCollider;
    [SerializeField] SpriteRenderer bodyRenderer;
    [Tooltip("Dipakai saat mulut dibuat solid agar mantul (Friction=0, Bounciness~0.9–1, Combine=Maximum).")]
    [SerializeField] PhysicsMaterial2D rimBouncyMaterial;

    [Header("Fireball Bounce Indicator (opsional)")]
    [Tooltip("Kalau SUDAH ada child indicator (mis. 'Trampoline'), drag ke sini. Kita ON/OFF saja.")]
    [SerializeField] GameObject fireballBounceIndicatorObject;
    [Tooltip("Atau instantiate prefab indikator saat Fireball aktif.")]
    [SerializeField] GameObject fireballBounceIndicatorPrefab;
    [Tooltip("Tempat spawn prefab indikator. Kosong = parent ke Bucket.")]
    [SerializeField] Transform indicatorAnchor;
    [Tooltip("OFF: true=Destroy, false=SetActive(false).")]
    [SerializeField] bool destroyIndicatorOnOff = false;

    [Header("SFX")]
    [Tooltip("Key di AudioManager untuk suara pantulan fireball di bucket.")]
    [SerializeField] string fireballBounceSfxKey = "fireballbounce";
    [Tooltip("Cooldown antar bunyi agar tidak spam.")]
    [SerializeField] float bounceSfxCooldown = 0.08f;
    [Tooltip("Kecepatan relatif minimum agar bunyi diputar.")]
    [SerializeField] float minRelativeSpeedForSfx = 0.2f;

    [Header("Skor Hole – Fever Basic (L→R)")]
    [SerializeField] int[] holeScoresBasic = { 50000, 25000, 10000, 25000, 50000 };

    [Header("Fever External")]
    [SerializeField] GameObject feverRoot;
    [SerializeField] GameObject holeWall;
    [SerializeField] AudioSource feverAS;

    public string FireballBounceSfxKey => fireballBounceSfxKey;
    public static BucketController Instance { get; private set; }

    // runtime state
    bool inFever;
    int[] activeHoleScores;
    float dir = 1f;
    bool hasCaughtThisTurn;
    bool holeClaimed;
    bool catchEnabled = true;

    // Fireball support
    bool forceMouthSolid = false;     // saat true: mulut non-trigger (memantul)
    GameObject indicatorInstance;     // jika pakai prefab
    float lastBounceSfxTime = -999f;

    void Awake()
    {
        Instance = this;

        if (feverRoot) feverRoot.SetActive(false);
        if (holeWall) holeWall.SetActive(false);

        activeHoleScores = holeScoresBasic;

        if (!normalCollider) normalCollider = GetComponent<CapsuleCollider2D>();
        UpdateColliderEnabled();
    }

    void Update()
    {
        if (inFever) return;

        transform.Translate(Vector2.right * dir * speed * Time.deltaTime);

        if (transform.position.x >= rightLimit && dir > 0f) dir = -1f;
        else if (transform.position.x <= leftLimit && dir < 0f) dir = 1f;
    }

    /* ==================== API Umum ==================== */

    public void SetCatchEnabled(bool on)
    {
        catchEnabled = on;
        UpdateColliderEnabled();
    }

    public bool IsCatchEnabled => catchEnabled;

    /// <summary>Paksa mulut ember jadi SOLID (non-trigger) supaya Fireball memantul. Toggle indikator.</summary>
    public void ForceSolidMouth(bool solid)
    {
        forceMouthSolid = solid;

        if (normalCollider)
        {
            normalCollider.isTrigger = !solid;
            normalCollider.sharedMaterial = solid ? rimBouncyMaterial : null;
            UpdateColliderEnabled();
        }

        // === INDICATOR ===
        if (fireballBounceIndicatorObject)
        {
            fireballBounceIndicatorObject.SetActive(solid);
        }
        else
        {
            if (solid)
            {
                if (fireballBounceIndicatorPrefab)
                {
                    if (!indicatorInstance)
                    {
                        var parent = indicatorAnchor ? indicatorAnchor : transform;
                        indicatorInstance = Instantiate(fireballBounceIndicatorPrefab, parent);
                        indicatorInstance.transform.localPosition = Vector3.zero;
                        indicatorInstance.transform.localRotation = Quaternion.identity;
                        indicatorInstance.transform.localScale = Vector3.one;
                    }
                    else indicatorInstance.SetActive(true);
                }
            }
            else
            {
                if (indicatorInstance)
                {
                    if (destroyIndicatorOnOff) { Destroy(indicatorInstance); indicatorInstance = null; }
                    else indicatorInstance.SetActive(false);
                }
            }
        }
    }

    void UpdateColliderEnabled()
    {
        if (!normalCollider) return;
        // Aktif bila:
        // - mode normal & catchEnabled & bukan fever, ATAU
        // - dipaksa solid (Fireball)
        normalCollider.enabled = (!inFever && catchEnabled) || forceMouthSolid;
    }

    /* ==================== FEVER ==================== */

    public void EnterFeverMode(bool all100k)
    {
        inFever = true;

        if (normalCollider) normalCollider.enabled = false;
        if (bodyRenderer) bodyRenderer.enabled = false;
        if (feverRoot) feverRoot.SetActive(true);
        if (holeWall) holeWall.SetActive(true);

        activeHoleScores = all100k
            ? new int[] { 100_000, 100_000, 100_000, 100_000, 100_000 }
            : holeScoresBasic;
    }

    public void OnBallEnteredHole(int holeIndex, GameObject ball)
    {
        if (feverAS && !feverAS.isPlaying) feverAS.Play();

        GameManager.Instance.RestoreTimeScale();

        if (!inFever || holeClaimed) return;
        holeClaimed = true;

        int bonus = (holeIndex >= 0 && holeIndex < activeHoleScores.Length)
            ? activeHoleScores[holeIndex]
            : 10000;

        ScoreManager.AddFever(bonus);

        Destroy(ball);
        GameManager.Instance.NotifyBallEnded();
    }

    /* ==================== CATCH NORMAL ==================== */

    void OnTriggerEnter2D(Collider2D other)
    {
        if (inFever) return;
        if (!catchEnabled) return;
        if (hasCaughtThisTurn || !other.CompareTag("Ball")) return;

        // Jangan tangkap Fireball (biarkan memantul)
        if (other.GetComponent<AposdaFireball>() != null) return;

        hasCaughtThisTurn = true;

        StyleShotManager.OnBucketCatch(transform.position);
        AudioManager.I.Play("BucketIn", transform.position);

        GameManager.Instance.GainBall(1);
        ScoreManager.AddFreeBallBonus();
        GameManager.Instance?.NotifyBallEnd(BallEndReason.Bucket);
        Destroy(other.gameObject);
    }

    /* ==================== SFX Pantul Fireball ==================== */

    // Dipanggil saat mulut sedang dibuat solid (forceMouthSolid = true).
    // Akan mainkan SFX ketika benturan pertama terjadi.
    void OnCollisionEnter2D(Collision2D col)
    {
        if (!forceMouthSolid) return;                 // hanya saat fireball-mode
        if (!col.collider || !col.collider.CompareTag("Ball")) return;

        // pastikan itu fireball-nya Aposda
        if (!col.collider.GetComponent<AposdaFireball>()) return;

        // throttle + threshold kecepatan
        if (col.relativeVelocity.magnitude < minRelativeSpeedForSfx) return;
        if (Time.time - lastBounceSfxTime < bounceSfxCooldown) return;

        Vector3 p = (col.contactCount > 0) ? (Vector3)col.GetContact(0).point : col.transform.position;
        if (!string.IsNullOrEmpty(fireballBounceSfxKey))
            AudioManager.I.Play(fireballBounceSfxKey, p);

        lastBounceSfxTime = Time.time;
    }

    public void ResetBucket()
    {
        hasCaughtThisTurn = false;
        holeClaimed = false;
    }
}
