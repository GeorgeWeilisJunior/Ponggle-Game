﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class FreeBallMeterUI : MonoBehaviour
{
    [SerializeField] private Image fillBar;
    [SerializeField] private Image glowOverlay;   // 🌟 overlay/shine di atas meter
    [SerializeField] private int pegThreshold = 25;
    int EffectiveThreshold => Mathf.Max(1, pegThreshold + (CardEffects.I ? CardEffects.I.freeBallThresholdDelta : 0));

    private int pegHitCount = 0;
    private bool hasAwardedThisShot = false;
    private Tween glowTween;                      // simpan animasi supaya bisa stop

    void OnEnable()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnBallUsed += ResetMeter;
    }

    void OnDisable()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnBallUsed -= ResetMeter;
    }

    public void RegisterPegHit()
    {
        pegHitCount++;

        float targetFill = Mathf.Clamp01((float)pegHitCount / EffectiveThreshold);
        fillBar.DOFillAmount(targetFill, 0.25f).SetEase(Ease.OutQuad);

        if (!hasAwardedThisShot && pegHitCount >= EffectiveThreshold)
        {
            hasAwardedThisShot = true;
            GameManager.Instance.GainBall(1);
            ScoreManager.AddFreeBallBonus();
            AudioManager.I.Play("FreeBallMeter", Camera.main.transform.position);
            Debug.Log("🎁 Free ball langsung diberikan dari meter!");

            ShowGlow();   // 🌟 efek terang
        }
    }

    public bool ReachedThreshold() => pegHitCount >= pegThreshold;

    public void ResetMeter()
    {
        pegHitCount = 0;
        hasAwardedThisShot = false;

        fillBar.DOFillAmount(0f, 0.3f).SetEase(Ease.InOutSine);

        HideGlow();   // 🌟 reset efek terang
    }

    /* ─────────── Glow Logic ─────────── */
    void ShowGlow()
    {
        if (!glowOverlay) return;

        glowOverlay.gameObject.SetActive(true);
        glowOverlay.color = new Color(1f, 1f, 1f, 0f);

        glowTween?.Kill();
        glowTween = glowOverlay.DOFade(0.5f, 0.6f)   // opacity naik 0.5
            .SetLoops(-1, LoopType.Yoyo)             // bolak-balik
            .SetEase(Ease.InOutSine);
    }

    void HideGlow()
    {
        if (!glowOverlay) return;

        glowTween?.Kill();
        glowOverlay.DOFade(0f, 0.2f).OnComplete(() =>
        {
            glowOverlay.gameObject.SetActive(false);
        });
    }
}
