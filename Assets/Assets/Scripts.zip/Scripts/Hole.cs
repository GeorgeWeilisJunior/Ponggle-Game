using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class Hole : MonoBehaviour
{
    [SerializeField] int holeIndex = 0;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Ball")) return;

        // akses singleton
        BucketController bucket = BucketController.Instance;
        if (bucket == null) return;   // proteksi ekstra

        bucket.OnBallEnteredHole(holeIndex, other.gameObject);
    }
}
