﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

[DisallowMultipleComponent]
public class AudioManager : MonoBehaviour
{
    public static AudioManager I { get; private set; }
    public static AudioManager Instance => I;

    [System.Serializable]
    public class SoundDef
    {
        public string key;
        public AudioClip clip;
        [Range(0f, 2f)] public float volume = 1f;
        [Range(.1f, 3f)] public float pitch = 1f;
        public bool randomizePitch = false;
        [Range(0f, 1f)] public float pitchRange = .1f;
    }

    [Header("SFX Library (one-shots)")]
    [SerializeField] List<SoundDef> sfxSounds = new();

    [Header("Music Library (BGM)")]
    [SerializeField] List<SoundDef> musicTracks = new();

    readonly Dictionary<string, SoundDef> sfxDict = new();
    readonly Dictionary<string, SoundDef> bgmDict = new();

    [Header("SFX Output & Pool")]
    [SerializeField] AudioMixerGroup sfxGroup;
    [SerializeField, Min(1)] int poolSize = 16;
    [SerializeField] float sfxSpatialBlend3D = 1f;
    [SerializeField] float sfxMinDistance = 1f;
    [SerializeField] float sfxMaxDistance = 30f;

    AudioSource[] pool;
    int head;

    [Header("Music (BGM) Output")]
    [SerializeField] AudioMixerGroup musicGroup;
    [SerializeField, Range(0f, 1f)] float musicVolume = 1f;

    [Header("Master Volume")]
    [SerializeField, Range(0f, 1f)] float sfxVolume = 1f;   // NEW

    // Main = gameplay BGM, Overlay = inventory/tutorial BGM
    AudioSource mainMusic;
    AudioSource overlayMusic;

    public bool IsMusicPlaying => mainMusic && mainMusic.isPlaying;
    public bool IsMusicPaused => mainMusic && !mainMusic.isPlaying && mainMusic.clip && mainMusic.time > 0f;

    void Awake()
    {
        if (I && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);

        BuildLibrary(sfxSounds, sfxDict);
        BuildLibrary(musicTracks, bgmDict);

        // SFX pool
        pool = new AudioSource[poolSize];
        for (int i = 0; i < poolSize; i++)
        {
            var src = gameObject.AddComponent<AudioSource>();
            src.playOnAwake = false;
            src.outputAudioMixerGroup = sfxGroup;
            src.spatialBlend = sfxSpatialBlend3D;
            src.minDistance = sfxMinDistance;
            src.maxDistance = sfxMaxDistance;
            pool[i] = src;
        }

        // Main gameplay music
        mainMusic = gameObject.AddComponent<AudioSource>();
        mainMusic.playOnAwake = false;
        mainMusic.loop = true;
        mainMusic.spatialBlend = 0f;
        mainMusic.outputAudioMixerGroup = musicGroup ? musicGroup : sfxGroup;
        mainMusic.volume = musicVolume;

        // Overlay music (untuk inventory / tutorial)
        overlayMusic = gameObject.AddComponent<AudioSource>();
        overlayMusic.playOnAwake = false;
        overlayMusic.loop = true;
        overlayMusic.spatialBlend = 0f;
        overlayMusic.outputAudioMixerGroup = musicGroup ? musicGroup : sfxGroup;
        overlayMusic.volume = musicVolume;
    }

    void BuildLibrary(List<SoundDef> list, Dictionary<string, SoundDef> dict)
    {
        dict.Clear();
        foreach (var s in list)
        {
            if (s == null || string.IsNullOrWhiteSpace(s.key) || s.clip == null) continue;
            if (!dict.ContainsKey(s.key)) dict.Add(s.key, s);
            else Debug.LogWarning($"[AudioManager] duplicate key '{s.key}' skipped.", this);
        }
    }

    /*──────────────── SFX ────────────────*/
    public void Play(string key, Vector3 position, float volumeScale = 1f, bool ignorePause = false)
    {
        if (!sfxDict.TryGetValue(key, out var def) || def.clip == null) return;
        var src = pool[head]; head = (head + 1) % pool.Length;
        src.transform.position = position;
        src.outputAudioMixerGroup = sfxGroup;
        src.spatialBlend = sfxSpatialBlend3D;
        src.ignoreListenerPause = ignorePause;
        src.clip = def.clip;
        src.volume = def.volume * sfxVolume * Mathf.Clamp01(volumeScale); // NEW
        src.pitch = def.randomizePitch ? Random.Range(def.pitch - def.pitchRange, def.pitch + def.pitchRange) : def.pitch;
        src.Play();
    }
    public void PlayUI(string key, float volumeScale = 1f, bool ignorePause = false)
    {
        if (!sfxDict.TryGetValue(key, out var def) || def.clip == null) return;
        var src = pool[head]; head = (head + 1) % pool.Length;
        src.transform.position = Vector3.zero;
        src.outputAudioMixerGroup = sfxGroup;
        src.spatialBlend = 0f;
        src.ignoreListenerPause = ignorePause;
        src.clip = def.clip;
        src.volume = def.volume * sfxVolume * Mathf.Clamp01(volumeScale); // NEW
        src.pitch = def.randomizePitch ? Random.Range(def.pitch - def.pitchRange, def.pitch + def.pitchRange) : def.pitch;
        src.Play();
    }
    public void PlayUI(string key, bool ignorePause) => PlayUI(key, 1f, ignorePause);

    /*──────────────── MAIN (gameplay) MUSIC — no fade ────────────────*/
    public void PlayMusic(string key, bool loop = true)
    {
        if (!bgmDict.TryGetValue(key, out var def) || def.clip == null) return;
        mainMusic.Stop();
        mainMusic.clip = def.clip;
        mainMusic.loop = loop;
        mainMusic.volume = musicVolume;
        mainMusic.pitch = 1f;
        mainMusic.Play();
    }
    public void StopMusic()
    {
        if (!mainMusic) return;
        mainMusic.Stop();
    }
    public void PauseMusic()
    {
        if (!mainMusic || !mainMusic.isPlaying) return;
        mainMusic.Pause();
    }
    public void ResumeMusic()
    {
        if (!mainMusic || !IsMusicPaused) return;
        mainMusic.UnPause();
    }

    // NEW: dipanggil SettingsPanel (0..1)
    public void SetSfxVolume01(float v)
    {
        sfxVolume = Mathf.Clamp01(v);
        // pool SFX akan pakai nilai ini saat Play()
    }

    public void SetMusicVolume01(float v)
    {
        // kalau kamu sudah punya 'musicVolume' serialized, cukup set & apply
        var nv = Mathf.Clamp01(v);
        // jika ada field musicVolume di script kamu, set juga:
        // musicVolume = nv;
        if (mainMusic) mainMusic.volume = nv;
        if (overlayMusic) overlayMusic.volume = nv;
    }

    /*──────────────── OVERLAY MUSIC — no fade ────────────────*/
    public void PlayOverlayMusic(string key, bool loop = true)
    {
        if (!bgmDict.TryGetValue(key, out var def) || def.clip == null) return;
        overlayMusic.Stop();
        overlayMusic.clip = def.clip;
        overlayMusic.loop = loop;
        overlayMusic.volume = musicVolume;
        overlayMusic.pitch = 1f;
        overlayMusic.Play();
    }
    public void StopOverlayMusic()
    {
        if (!overlayMusic) return;
        overlayMusic.Stop();
    }
}
