﻿using DG.Tweening;
using TMPro;
using UnityEngine;

public class PegScorePopup : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI label;
    [SerializeField] float rise = 0.6f;
    [SerializeField] float duration = 0.6f;

    public void Show(int amount)
    {
        label.text = $"{amount}";
        var cg = GetComponent<CanvasGroup>();
        cg.alpha = 1;

        Vector3 start = transform.position;                    // posisi world
        Vector3 end = start + Vector3.up * rise;             // naik 0.6 unit

        Sequence s = DOTween.Sequence();
        s.Join(transform.DOMove(end, duration).SetEase(Ease.OutQuad)); // ★ DOMove (world)
        s.Join(cg.DOFade(0, duration));
        s.OnComplete(() => Destroy(gameObject));
    }
}
