﻿using UnityEngine;
using System.Collections.Generic;

/// Lintasan bidik akurat & sinkron dengan Launcher.
public class AimGuide : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] GameObject dotPrefab;
    [SerializeField] BallController ballPrefab;   // prefab bola yg sama dg Launcher

    [Header("Guide Settings")]
    [SerializeField] float timeToPeak = .45f;     // akan di-override dari Launcher
    [SerializeField] float baseDistance = 6f;     // akan di-override dari Launcher
    [SerializeField] float minFactor = 0.5f, maxFactor = 2f;
    [SerializeField] int maxDots = 75;
    [SerializeField] LayerMask hitMask = ~0;

    [Header("Triple-Shot")]
    [SerializeField] float tripleSpreadDeg = 10f;

    [Header("End Ball Visual (Optional)")]
    [SerializeField] GameObject endBallPrefab;
    [Range(0, 1)][SerializeField] float endBallAlpha = 0.55f;
    [SerializeField] string endBallSortingLayer = "Default";
    [SerializeField] int endBallSortingOrder = 2;

    [Header("Tuning")]
    [Tooltip("Tambah skala radius utk konservatif (1.0 = sama persis).")]
    [SerializeField] float radiusScale = 1.03f;
    [Tooltip("Margin ekstra (world units).")]
    [SerializeField] float radiusBias = 0.002f;

    readonly List<Transform> dotsC = new();
    readonly List<Transform> dotsL = new();
    readonly List<Transform> dotsR = new();

    Transform endC, endL, endR;
    SpriteRenderer ballSR;
    float ballRadius = .2f;
    float step => Time.fixedDeltaTime;

    void Awake()
    {
        // pool titik
        for (int i = 0; i < maxDots; i++)
        {
            dotsC.Add(Instantiate(dotPrefab, transform).transform);
            dotsL.Add(Instantiate(dotPrefab, transform).transform);
            dotsR.Add(Instantiate(dotPrefab, transform).transform);
            dotsC[i].gameObject.SetActive(false);
            dotsL[i].gameObject.SetActive(false);
            dotsR[i].gameObject.SetActive(false);
        }

        // ghost-ball
        if (endBallPrefab)
        {
            endC = BuildEndBall();
            endL = BuildEndBall();
            endR = BuildEndBall();
        }
    }

    void OnEnable()
    {
        // hitung radius akurat dengan membuat 1 instance dummy (root, tanpa parent scale)
        RecomputeBallRadiusRuntime();
    }

    void RecomputeBallRadiusRuntime()
    {
        if (!ballPrefab) return;
        var dummy = Instantiate(ballPrefab, Vector3.one * 9999f, Quaternion.identity);
        float r = .2f;

        var col = dummy.GetComponent<CircleCollider2D>();
        if (col)
        {
            // gunakan lossyScale aktual di runtime
            float scl = Mathf.Max(dummy.transform.lossyScale.x, dummy.transform.lossyScale.y);
            r = col.radius * scl;
        }
        else
        {
            ballSR = dummy.GetComponentInChildren<SpriteRenderer>();
            if (ballSR) r = ballSR.bounds.extents.x;
        }

        DestroyImmediate(dummy.gameObject);
        ballRadius = r * Mathf.Max(1f, radiusScale) + Mathf.Max(0f, radiusBias);
    }

    Transform BuildEndBall()
    {
        var t = Instantiate(endBallPrefab, transform).transform;
        t.gameObject.SetActive(false);
        if (t.TryGetComponent<SpriteRenderer>(out var sr))
        {
            if (!sr.sprite)
            {
                if (!ballSR) ballSR = ballPrefab ? ballPrefab.GetComponentInChildren<SpriteRenderer>() : null;
                if (ballSR) sr.sprite = ballSR.sprite;
            }
            if (ballSR && sr.bounds.size.x > 0f)
            {
                float scale = ballSR.bounds.size.x / sr.bounds.size.x;
                t.localScale *= scale;
            }
            sr.sortingLayerName = endBallSortingLayer;
            sr.sortingOrder = endBallSortingOrder;
            var c = sr.color; c.a = endBallAlpha; sr.color = c;
        }
        return t;
    }

    void OnDisable()
    {
        HidePool(dotsC); HidePool(dotsL); HidePool(dotsR);
        if (endC) endC.gameObject.SetActive(false);
        if (endL) endL.gameObject.SetActive(false);
        if (endR) endR.gameObject.SetActive(false);
    }

    void HidePool(List<Transform> pool)
    {
        for (int i = 0; i < pool.Count; i++)
            if (pool[i]) pool[i].gameObject.SetActive(false);
    }

    void LateUpdate()
    {
        if (!Launcher.Instance) { OnDisable(); return; }
        var cam = Camera.main; if (!cam) return;

        // --- sinkron nilai dari Launcher (anti mismatch Inspector)
        timeToPeak = Launcher.Instance.TimeToPeak;     // new getter
        baseDistance = Launcher.Instance.AimDistance;    // new getter

        // ambil mouse dgn z yang sama seperti Launcher
        var mp = Input.mousePosition;
        mp.z = Mathf.Abs(cam.transform.position.z - Launcher.Instance.PivotPos.z);
        Vector3 mouse = cam.ScreenToWorldPoint(mp);
        mouse.z = Launcher.Instance.PivotPos.z;

        // arah di-clamp pakai fungsi Launcher (sudut identik)
        Vector2 dirUnit = Launcher.Instance.ClampDir((Vector2)(mouse - Launcher.Instance.PivotPos)); // :contentReference[oaicite:3]{index=3}

        float factor = Mathf.Lerp(minFactor, maxFactor, Mathf.Clamp01(GlobalSettings.GuideLength));
        // panjang lintasan mengikuti slider
        float usedDistance = Launcher.Instance.AimDistance * factor;
        Vector3 origin = Launcher.Instance.SpawnPos;
        Vector3 target = origin + (Vector3)dirUnit * usedDistance;

        float g = Physics2D.gravity.y * (ballPrefab ? ballPrefab.GravityScale : 1f);

        Vector2 v0C = CalculateV0(origin, target, timeToPeak, g); // rumus sama dgn Launcher  :contentReference[oaicite:5]{index=5}

        bool triple = CharacterPowerManager.Instance &&
                      CharacterPowerManager.Instance.nextShotTripleBall;

        Vector2 lastC; int usedC = DrawPath(dotsC, v0C, g, true, out lastC);

        if (triple)
        {
            Vector2 vL = Quaternion.Euler(0, 0, tripleSpreadDeg) * v0C;
            Vector2 vR = Quaternion.Euler(0, 0, -tripleSpreadDeg) * v0C;

            Vector2 lastL, lastR;
            int usedL = DrawPath(dotsL, vL, g, true, out lastL);
            int usedR = DrawPath(dotsR, vR, g, true, out lastR);

            SetEnd(endC, usedC > 0, lastC);
            SetEnd(endL, usedL > 0, lastL);
            SetEnd(endR, usedR > 0, lastR);
        }
        else
        {
            DrawPath(dotsL, v0C, g, false, out _);
            DrawPath(dotsR, v0C, g, false, out _);
            SetEnd(endL, false, Vector2.zero);
            SetEnd(endR, false, Vector2.zero);
            SetEnd(endC, usedC > 0, lastC);
        }
    }

    int DrawPath(List<Transform> pool, Vector2 v0, float g, bool on, out Vector2 lastPos)
    {
        Vector2 pos = Launcher.Instance.SpawnPos;
        Vector2 vel = v0;
        int used = 0; lastPos = pos;

        for (int i = 0; i < maxDots; i++)
        {
            pool[i].gameObject.SetActive(on);
            if (!on) continue;

            pool[i].position = pos; used++; lastPos = pos;

            Vector2 nxt = pos + vel * step + 0.5f * Vector2.up * g * step * step;
            Vector2 seg = nxt - pos;
            float dist = seg.magnitude;

            if (dist > 0f)
            {
                Vector2 dir = seg / dist;
                var hit = Physics2D.CircleCast(pos, ballRadius, dir, dist, hitMask);
                if (hit.collider != null)
                {
                    lastPos = hit.centroid - dir * (ballRadius + 0.003f);
                    break;
                }
            }

            vel += Vector2.up * g * step;
            pos = nxt;
        }

        for (int i = used; i < maxDots; i++)
            if (pool[i].gameObject.activeSelf) pool[i].gameObject.SetActive(false);

        return used;
    }

    void SetEnd(Transform end, bool on, Vector2 p)
    {
        if (!end) return;
        end.gameObject.SetActive(on);
        if (on) end.position = p;
    }

    Vector2 CalculateV0(Vector3 o, Vector3 t, float tp, float g)
    {
        Vector3 d = t - o;
        float v0x = d.x / tp;
        float v0y = d.y / tp - 0.5f * g * tp;
        return new Vector2(v0x, v0y);
    }
}
