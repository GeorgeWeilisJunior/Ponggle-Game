using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Collections;

[RequireComponent(typeof(CanvasGroup))]
public class UIAutoHideScrollbar : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] ScrollRect scrollRect;
    [SerializeField] float visibleAlpha = 1f;
    [SerializeField] float hiddenAlpha = 0f;
    [SerializeField] float fadeTime = .2f;
    [SerializeField] float idleHideDelay = 1.2f;

    CanvasGroup cg;
    Coroutine fadeCo, hideCo;
    bool pointerInside;

    void Awake()
    {
        cg = GetComponent<CanvasGroup>();
        if (!scrollRect) scrollRect = GetComponentInParent<ScrollRect>();
        SetAlpha(hiddenAlpha);
    }

    void OnEnable()
    {
        if (scrollRect) scrollRect.onValueChanged.AddListener(_ => OnUserScrolled());
    }
    void OnDisable()
    {
        if (scrollRect) scrollRect.onValueChanged.RemoveListener(_ => OnUserScrolled());
    }

    public void OnPointerEnter(PointerEventData e) { pointerInside = true; Show(); }
    public void OnPointerExit(PointerEventData e) { pointerInside = false; DelayedHide(); }

    void OnUserScrolled() { Show(); DelayedHide(); }

    void Show()
    {
        if (hideCo != null) StopCoroutine(hideCo);
        FadeTo(visibleAlpha);
    }
    void DelayedHide()
    {
        if (hideCo != null) StopCoroutine(hideCo);
        hideCo = StartCoroutine(HideAfterDelay());
    }
    IEnumerator HideAfterDelay()
    {
        yield return new WaitForSeconds(idleHideDelay);
        if (!pointerInside) FadeTo(hiddenAlpha);
    }

    void FadeTo(float a)
    {
        if (fadeCo != null) StopCoroutine(fadeCo);
        fadeCo = StartCoroutine(FadeRoutine(a));
    }
    IEnumerator FadeRoutine(float target)
    {
        float start = cg.alpha, t = 0f;
        while (t < fadeTime)
        {
            t += Time.unscaledDeltaTime;
            SetAlpha(Mathf.Lerp(start, target, t / fadeTime));
            yield return null;
        }
        SetAlpha(target);
    }
    void SetAlpha(float a) => cg.alpha = a;

    public static void NotifyUserScrolled(ScrollRect sr)
    {
        if (!sr) return;
        var h = sr.GetComponentInChildren<UIAutoHideScrollbar>(true);
        if (h) h.OnUserScrolled();
    }
}
