using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[DefaultExecutionOrder(-500)]
public class LocalLeaderboardManager : MonoBehaviour
{
    public static LocalLeaderboardManager I { get; private set; }

    [Serializable]
    public class Entry
    {
        public string name = "YOU";
        public int score;
        public long timestamp; // unix
    }

    [Serializable]
    class Board
    {
        public List<Entry> entries = new List<Entry>();
        public int keepTop = 50; // simpan sampai 50; UI hanya menampilkan 12
    }

    [Serializable]
    class DB
    {
        // key bebas, misal "Adventure_All25"
        public Dictionary<string, Board> boards = new Dictionary<string, Board>();
    }

    public event Action OnChanged;

    DB db = new DB();
    string FilePath => Path.Combine(Application.persistentDataPath, "leaderboard_local.json");

    void Awake()
    {
        if (I && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
        Load();
    }

    // ====== PUBLIC API ======
    public void Submit(string boardKey, string playerName, int score)
    {
        if (!db.boards.TryGetValue(boardKey, out var b))
        {
            b = new Board();
            db.boards[boardKey] = b;
        }

        if (string.IsNullOrWhiteSpace(playerName)) playerName = "YOU";

        var e = new Entry
        {
            name = playerName.Trim(),
            score = score,
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
        };

        b.entries.Add(e);
        // besar -> kecil
        b.entries.Sort((a, c) => c.score.CompareTo(a.score));
        if (b.entries.Count > b.keepTop)
            b.entries.RemoveRange(b.keepTop, b.entries.Count - b.keepTop);

        Save();
        OnChanged?.Invoke();
    }

    public IReadOnlyList<Entry> GetTop(string boardKey, int maxCount = 12)
    {
        if (!db.boards.TryGetValue(boardKey, out var b) || b.entries == null)
            return Array.Empty<Entry>();
        int n = Mathf.Min(maxCount, b.entries.Count);
        return b.entries.GetRange(0, n);
    }

    public void ClearAll()
    {
        db = new DB();
        Save();
        OnChanged?.Invoke();
    }

    // ====== IO ======
    void Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                db = JsonUtility.FromJson<DB>(File.ReadAllText(FilePath)) ?? new DB();
            }
        }
        catch { db = new DB(); }
    }

    void Save()
    {
        try
        {
            File.WriteAllText(FilePath, JsonUtility.ToJson(db, true));
        }
        catch { /* ignore */ }
    }
}
