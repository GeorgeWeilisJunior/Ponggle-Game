﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class NameEntryUI : MonoBehaviour
{
    [Header("Refs")]
    public CanvasGroup cg;          // optional (kalau ada PanelFader, tetap oke)
    public Button btnClose;
    public TMP_Text txtA, txtB, txtC;

    // Bisa Image atau TMP_Text
    public Graphic usA, usB, usC;   // underscore A/B/C
    public Button btnConfirm;

    [Header("Visual")]
    public Color normalColor = Color.white;
    public Color highlightColor = new Color(1f, 0.85f, 0.3f);
    public float blinkSpeed = 6f;
    [Range(0f, 1f)] public float offAlpha = 0.20f;
    [Range(0f, 1f)] public float idleAlpha = 0.55f;

    [Header("Integration")]
    public MenuManager menu;        // drag MenuManager
    public string firstLevelSceneOverride = "";

    int cursor = 0;                 // 0=A,1=B,2=C
    char[] letters = new char[3] { 'A', 'A', 'A' };
    Coroutine blinkCo;

    public void UI_SelectA() => SetCursor(0);
    public void UI_SelectB() => SetCursor(1);
    public void UI_SelectC() => SetCursor(2);

    void Reset()
    {
        cg = GetComponent<CanvasGroup>();
    }

    void Awake()
    {
        if (btnClose) btnClose.onClick.AddListener(Hide);
        if (btnConfirm) btnConfirm.onClick.AddListener(OnConfirm);

        // Init dari SaveManager (fallback "YOU")
        string saved = (SaveManager.I != null) ? SaveManager.I.Data.playerName : "YOU";
        saved = string.IsNullOrWhiteSpace(saved) ? "YOU" : saved.Trim().ToUpperInvariant();

        if (saved.Length >= 3)
        {
            letters[0] = saved[0];
            letters[1] = saved[1];
            letters[2] = saved[2];
        }

        RefreshTexts();
        SetCursor(0);
        HideImmediate();
    }

    void Update()
    {
        if (!gameObject.activeInHierarchy) return;

        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) MoveCursor(-1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) MoveCursor(+1);
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) NudgeLetter(+1);
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) NudgeLetter(-1);

        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            OnConfirm();

        if (Input.GetKeyDown(KeyCode.Escape)) Hide();
    }

    // ==== Show/Hide ====
    public void Show()
    {
        gameObject.SetActive(true);
        RefreshTexts();
        SetCursor(0);
        if (menu) menu.ShowDim();

        if (TryGetComponent<PanelFader>(out var pf)) pf.Show();
        else if (cg) { cg.alpha = 1f; cg.blocksRaycasts = true; cg.interactable = true; }
    }

    public void Hide()
    {
        StopBlink();
        if (TryGetComponent<PanelFader>(out var pf))
        {
            pf.Hide(() => {
                gameObject.SetActive(false);
                if (menu) menu.HideDim();
            });
        }
        else
        {
            if (cg) { cg.alpha = 0f; cg.blocksRaycasts = false; cg.interactable = false; }
            gameObject.SetActive(false);
            if (menu) menu.HideDim();
        }
    }

    public void HideImmediate()
    {
        if (cg) { cg.alpha = 0f; cg.blocksRaycasts = false; cg.interactable = false; }
        gameObject.SetActive(false);
        StopBlink();
    }

    // ==== Logic ====
    public void UI_Left() => MoveCursor(-1);
    public void UI_Right() => MoveCursor(+1);
    public void UI_Up() => NudgeLetter(+1);
    public void UI_Down() => NudgeLetter(-1);

    void MoveCursor(int dir)
    {
        cursor = Mathf.Clamp(cursor + dir, 0, 2);
        SetCursor(cursor);
    }

    void SetCursor(int i)
    {
        cursor = Mathf.Clamp(i, 0, 2);

        if (txtA) txtA.color = (cursor == 0) ? highlightColor : normalColor;
        if (txtB) txtB.color = (cursor == 1) ? highlightColor : normalColor;
        if (txtC) txtC.color = (cursor == 2) ? highlightColor : normalColor;

        SetGraphicAlpha(usA, idleAlpha);
        SetGraphicAlpha(usB, idleAlpha);
        SetGraphicAlpha(usC, idleAlpha);

        StopBlink();
        blinkCo = StartCoroutine(BlinkUnderscore());
    }

    System.Collections.IEnumerator BlinkUnderscore()
    {
        Graphic active = cursor == 0 ? usA : cursor == 1 ? usB : usC;
        if (!active) yield break;

        while (true)
        {
            float t = (Mathf.Sin(Time.unscaledTime * blinkSpeed) + 1f) * 0.5f; // 0..1
            float a = Mathf.Lerp(offAlpha, 1f, t);
            SetGraphicAlpha(active, a);
            yield return null;
        }
    }

    void StopBlink()
    {
        if (blinkCo != null) { StopCoroutine(blinkCo); blinkCo = null; }
    }

    void SetGraphicAlpha(Graphic g, float a)
    {
        if (!g) return;
        var c = g.color; c.a = a; g.color = c;
    }

    void NudgeLetter(int delta)
    {
        int idx = cursor;
        char c = letters[idx];
        if (c < 'A' || c > 'Z') c = 'A';
        int off = c - 'A';
        off = (off + delta) % 26;
        if (off < 0) off += 26;
        letters[idx] = (char)('A' + off);

        RefreshTexts();
    }

    void RefreshTexts()
    {
        if (txtA) txtA.text = letters[0].ToString();
        if (txtB) txtB.text = letters[1].ToString();
        if (txtC) txtC.text = letters[2].ToString();
    }

    void OnConfirm()
    {
        string initials = new string(letters).ToUpperInvariant();

        // Simpan + reset run via SaveManager
        if (SaveManager.I) SaveManager.I.NewGame(initials);

        Hide(); // rapi
        if (menu) menu.StartNewGameAfterName(firstLevelSceneOverride);
    }
}
