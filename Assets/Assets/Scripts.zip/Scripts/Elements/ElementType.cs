public enum ElementType { Neutral, Fire, Water, Wind, Earth }
