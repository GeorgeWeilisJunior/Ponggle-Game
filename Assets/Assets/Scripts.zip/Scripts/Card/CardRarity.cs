public enum CardRarity
{
    Common,
    Rare,
    Epic,
    Legendary
}
