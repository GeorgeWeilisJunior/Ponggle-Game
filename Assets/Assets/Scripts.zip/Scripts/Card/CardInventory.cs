﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CardInventory : MonoBehaviour
{
    public static CardInventory I { get; private set; }

    [System.Serializable]
    public class OwnedCard
    {
        public CardData data;
        public int stacks = 1;
    }

    [Header("Owned Cards (run only)")]
    [SerializeField] List<OwnedCard> owned = new();

    [Header("Picked Build (dibawa ke level berikutnya)")]
    [SerializeField, Min(1)] int energyLimit = 10;
    [SerializeField] List<CardData> picked = new();

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
    }

    // ==== NEW: sync dari Save ====
    public void LoadFromSave()
    {
        owned.Clear();
        picked.Clear();

        if (SaveManager.I == null) return;

        // energy limit
        energyLimit = Mathf.Max(1, SaveManager.I.Data.energyLimit);

        // owned
        if (SaveManager.I.Data.ownedCards != null)
        {
            foreach (var id in SaveManager.I.Data.ownedCards)
            {
                var cd = CardLibrary.GetById(id);
                if (cd) AddCard(cd);
            }
        }

        // picked for next
        if (SaveManager.I.Data.pickedForNext != null)
        {
            foreach (var id in SaveManager.I.Data.pickedForNext)
            {
                var cd = CardLibrary.GetById(id);
                if (cd) picked.Add(cd);
            }
        }
    }

    // ── Readonly views ───────────────────────────────────────────
    public IReadOnlyList<OwnedCard> Owned => owned;
    public IReadOnlyList<CardData> Picked => picked;
    public int EnergyLimit => energyLimit;
    public int EnergyUsed => picked.Sum(c => Mathf.Max(0, c ? c.energyCost : 0));
    public void SetEnergyLimit(int v) { energyLimit = Mathf.Max(1, v); }

    // ── Owned ops ────────────────────────────────────────────────
    public void ClearAll()
    {
        owned.Clear();
        picked.Clear();
    }

    public void AddCard(CardData card)
    {
        if (!card) return;

        if (card.stackable)
        {
            var found = owned.Find(o => o.data == card);
            if (found != null)
            {
                found.stacks = Mathf.Min(found.stacks + 1, card.maxStacks);
                return;
            }
        }
        owned.Add(new OwnedCard { data = card, stacks = 1 });
    }

    public bool RemoveCard(CardData card)
    {
        int idx = owned.FindIndex(o => o.data == card);
        if (idx < 0) return false;

        if (owned[idx].data.stackable && owned[idx].stacks > 1)
            owned[idx].stacks--;
        else
            owned.RemoveAt(idx);

        return true;
    }

    // ── Pick/Unpick ops ──────────────────────────────────────────
    public bool CanPick(CardData card, out string reason)
    {
        reason = null;
        if (!card) { reason = "not_found"; return false; }
        if (!card.stackable && picked.Contains(card)) { reason = "duplicate"; return false; }

        int newEnergy = EnergyUsed + Mathf.Max(0, card.energyCost);
        if (newEnergy > energyLimit) { reason = "energy"; return false; }

        if (card.stackable)
        {
            int ownedStacks = owned.Where(o => o.data == card).Sum(o => o.stacks);
            int pickedCount = picked.Count(c => c == card);
            if (pickedCount >= ownedStacks) { reason = "no_stack"; return false; }
        }
        return true;
    }

    public bool TryPick(CardData card, out string reason)
    {
        if (!CanPick(card, out reason)) return false;
        picked.Add(card);
        return true;
    }

    public bool TryUnpick(CardData card)
    {
        return picked.Remove(card);
    }

    // ── Helpers jumlah ───────────────────────────────────────────
    public int GetOwnedCount(CardData c)
    {
        if (!c) return 0;
        return owned.Where(o => o != null && o.data == c)
                    .Sum(o => Mathf.Max(1, o.stacks));
    }

    public int GetPickedCount(CardData c)
    {
        if (!c) return 0;
        return picked.Count(p => p == c);
    }

    public int GetAvailableCount(CardData c) => GetOwnedCount(c) - GetPickedCount(c);
    public int GetTotalEnergySelected() => EnergyUsed;
}
